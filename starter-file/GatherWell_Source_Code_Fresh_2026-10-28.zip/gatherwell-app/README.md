# GatherWell — Social Event Guest & Registration Management

A single-organization Next.js 15 / React 19 / TypeScript organizer-only application following the October 2026 *Social Event Guest & Registration Management — Technical Overview* and the forest-green accessible HTML wireframes.

**Scope:** manage internal event registration records, CSV/XLSX imports, guests, meals, table seating, reports, cloning, and external registration/payment status labels. **Not a public ticket checkout or payment processing product.**

## Requirements

- Node.js 20 or later, npm
- Neon PostgreSQL database
- Vercel account for hosting
- GitHub account for source control
- A strong Better Auth secret

## Local setup

```bash
npm install
cp .env.example .env.local
# Fill in DATABASE_URL, BETTER_AUTH_SECRET, BETTER_AUTH_URL, and BOOTSTRAP_ADMIN_EMAIL
npm run db:push
npm run dev
```

Visit `http://localhost:3000/login`, create an account with the same email address as `BOOTSTRAP_ADMIN_EMAIL`, and initialize your single organization. This user is the owner. GatherWell only allows the first organization to be created; all staff and events belong to that organization. Signups without a membership cannot see event records. As owner, create an invitation link from Staff & Access and share it privately. Other users create accounts via that invitation link.

Optional demo event, after bootstrap:

```bash
npm run seed
```

## Deployment to Vercel

1. Create a private GitHub repository and push the **project contents**. Never commit `.env.local`.
2. Import your repository as a Next.js project in Vercel. Configure environment variables from `.env.example` using actual credentials.
3. Set `BETTER_AUTH_URL` and `NEXT_PUBLIC_APP_URL` to your exact HTTPS Vercel/custom domain.
4. Apply the database schema **before** opening production: locally `npm run db:push` with production `DATABASE_URL`, or use generated reviewed migrations with `npm run db:generate && npm run db:migrate`.
5. Deploy and sign in with the bootstrap owner email.
6. Configure backups/retention in Neon and access restrictions on GitHub and Vercel. For password reset email, configure a supported mail delivery adapter before enabling the feature for staff.

## Modules

- Events: create/edit/clone; copying configuration never copies registrations or history.
- Registrations: manual purchaser records and recorded status from external sources, capacity check.
- Imports: browser parses .csv/.xls/.xlsx; previews new vs duplicate vs review; server revalidates; unchanged external identifiers are skipped; original files are not retained.
- Guests: individual guest rows, meal options, dietary notes and seating preferences.
- Seating: table count and capacity; unique guest/seat database constraints; print table rosters.
- Meals: configurable event options and missing-meal reports.
- Reports: US Letter browser print / PDF and Excel download with spreadsheet formula escaping.
- Access: Better Auth credential login and organization membership roles (owner, manager, viewer).

## Known production-readiness work

This is a functional implementation starter, **not a certified production release**. Perform a full review before storing sensitive attendee data. Critical follow-ups: real test suite and import concurrency/retry tests; rate limiting and anti-abuse controls; transactional bulk imports and manual registration writes (some operations currently span multiple SQL statements); atomic seat moves under concurrency; stronger fine-grained read restrictions for dietary notes (the snapshot currently returns those notes to all event members); email provider integration for password reset; formal WCAG 2.2 AA evaluation; backups/restore drills; and reliable external registration format mapping. No integrations with external platforms or payment services are configured.

**Important:** the Neon HTTP driver is excellent for short queries, but multi-statement atomic operations require a transaction-capable driver or PostgreSQL function. The current app cannot guarantee all invariants under concurrent editing, and it should be treated as a staging build until these hardening tasks are completed.

## Reference materials

- `Social_Event_Guest_Management_Technical_Overview.pdf` — primary technical and scope source
- `Social_Event_Management_FULL_Interactive_Wireframes.html` — UI reference

## Privacy

No uploaded source file is retained. Browser sends normalized rows (names and contact data) to Neon for persistence; imported original files stay in the browser. Access to a stored event requires organizational membership. Never use this repository with real guest allergy information before resolving the fine-grained access issue above.

## Confirmed deployment decisions (October 2026)

- Product name: **GatherWell**.
- Organization model: **one organization only**. Initialize it once using `BOOTSTRAP_ADMIN_EMAIL`; additional organizers and event-day helpers are invited as staff.
- A single organization can create and clone many events, each with separate registrations and historical records.
- Keep organization IDs as foreign keys for record ownership and access checks; the app does not expose additional organization creation after initial setup.
